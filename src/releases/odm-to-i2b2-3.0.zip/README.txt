This readme is meant for users who want to install and use ODM-to-i2b2 in order to convert an ODM file to three tabular files. The tool needs two command line parameters, the first with an ODM/XML file and the input directory in which it can be found, the second with the output directory in which the converted files will be put. Apart from the jar file with the code, an ODM-to-i2b2.properties file is required for reading in some properties that can be modified manually. For executing the tool, follow this procedure:

Save your ODM file in odm-to-i2b2-3.0\input-ODMs (e.g. odm130.XML)
Start the command line terminal (e.g. cmd.exe)
$ cd C:\path\to\odm-to-i2b2-3.0
$ java -jar odm-to-i2b2-3.0.jar input-ODMs\odm130.XML output-tabular-files
$ cd output-tabular-files
$ ls -l
